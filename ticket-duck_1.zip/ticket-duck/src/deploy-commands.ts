/**
 * Script standalone opcional para registrar os slash commands manualmente.
 * Uso: `npm run deploy-commands`
 *
 * NÃO é mais necessário para o funcionamento normal do bot — o registro
 * já acontece automaticamente a cada `npm start` (ver src/index.ts).
 * Mantido apenas para quem quiser forçar um redeploy dos comandos sem
 * reiniciar o processo do bot.
 */
import { logger } from './utils/logger.js';
import { loadCommands } from './utils/commandLoader.js';
import { deployCommands } from './utils/deployCommands.js';

loadCommands()
  .then((commands) => deployCommands(commands))
  .catch((error) => {
    logger.fatal({ error }, 'Falha ao registrar comandos');
    process.exit(1);
  });
