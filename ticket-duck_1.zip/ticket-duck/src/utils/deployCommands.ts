import { REST, Routes } from 'discord.js';
import type { Collection } from 'discord.js';
import { env } from '../config/env.js';
import { logger } from './logger.js';
import type { Command } from '../types/client.js';

/**
 * Registra (via PUT — substitui a lista inteira) os slash commands na API do
 * Discord. É seguro chamar isso toda vez que o bot inicia: o endpoint de
 * bulk overwrite é idempotente — se os comandos não mudaram, o Discord não
 * faz nada de diferente, e não há penalidade de rate limit por repetir.
 *
 * Se DEV_GUILD_ID estiver definido, registra apenas nessa guild (propaga
 * instantaneamente — ideal para dev). Caso contrário, registra globalmente
 * (pode levar até 1 hora para propagar em todos os servidores).
 */
export async function deployCommands(commands: Collection<string, Command>): Promise<void> {
  const body = [...commands.values()].map((c) => c.data.toJSON());
  const rest = new REST().setToken(env.DISCORD_TOKEN);

  try {
    if (env.DEV_GUILD_ID) {
      await rest.put(Routes.applicationGuildCommands(env.DISCORD_CLIENT_ID, env.DEV_GUILD_ID), { body });
      logger.info(`${body.length} slash command(s) registrados na guild de desenvolvimento (${env.DEV_GUILD_ID}).`);
    } else {
      await rest.put(Routes.applicationCommands(env.DISCORD_CLIENT_ID), { body });
      logger.info(`${body.length} slash command(s) registrados globalmente (pode levar até 1h para propagar).`);
    }
  } catch (error) {
    // Não derruba o bot por causa disso — o bot deve continuar online mesmo
    // que o registro falhe (ex.: instabilidade momentânea da API do Discord).
    logger.error({ error }, 'Falha ao registrar slash commands na API do Discord.');
  }
}
